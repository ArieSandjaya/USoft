using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using USoft.Globalization.Classes;
using USoft.Common.Shared;
using System.Collections.Generic;
using USoft.Marketing.CashReward;

namespace USoft.Modules.Marketing.CashReward
{
    public partial class CashReward : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ControlBindingHelper.BindMyDropDownListAsBranch(ddlBranch, false);
                ControlBindingHelper.BindMyDropDownListAsBrand(ddlBrand, false);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Show(1,true);
        }

        private void Show(int MinRow,bool NewSearch)
        {
            List<KeyValuePair<string, object>> ParameterCollection = new List<KeyValuePair<string, object>>();
            ParameterCollection.Add(new KeyValuePair<string, object>("@PERIOD", txtPeriod.Text));
            ParameterCollection.Add(new KeyValuePair<string, object>("@CONDITION", ddlAssetCondition.SelectedValue));
            ParameterCollection.Add(new KeyValuePair<string, object>("@BRAND", ddlBrand.SelectedItem.Text));
            ParameterCollection.Add(new KeyValuePair<string, object>("@BRANCH", ddlBranch.SelectedValue));
            ParameterCollection.Add(new KeyValuePair<string, object>("@TYPE", 0));
            GetCashReward.Show(ParameterCollection, gvCashReward, CtrlPager,MinRow,NewSearch);
        }

        public void NextPager(object sender, EventArgs e)
        {
            Label lblCurrPage = (Label)CtrlPager.FindControl("lblCurrent");
            Show(Convert.ToInt16(lblCurrPage.Text),false);
        }

        public void PrevPager(object sender, EventArgs e)
        {
            Label lblCurrPage = (Label)CtrlPager.FindControl("lblCurrent");
            Show(Convert.ToInt16(lblCurrPage.Text), false);
        }

        protected void gvCashReward_RowDataBound(object sender, GridViewRowEventArgs e)
        {            
            if(e.Row.RowType == DataControlRowType.DataRow)
            {
                string period =  e.Row.Cells[1].Text;
                string contractId = e.Row.Cells[2].Text;
                string SupplierType = e.Row.Cells[3].Text;
                string RefundRecId = e.Row.Cells[4].Text;
                string SupplierCode = e.Row.Cells[5].Text;
                string BrandCode = e.Row.Cells[6].Text;
                CheckBox chkPaid = (CheckBox)e.Row.FindControl("chkPaid");
                CheckBox chkLater = (CheckBox)e.Row.FindControl("chkLater");
                TextBox tBox = (TextBox)e.Row.FindControl("txtAmountRewardPaid");
                decimal iTax = Convert.ToDecimal(((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[33].ToString());
                chkPaid.Attributes.Add("onclick", "SelectionCheckBox('" + period + "','" + contractId + "','" + SupplierType + "','" + RefundRecId + "','" + SupplierCode + "','" + BrandCode + "'," + "this" + ",'cpaid')");
                chkLater.Attributes.Add("onclick", "SelectionCheckBox('" + period + "','" + contractId + "','" + SupplierType + "','" + RefundRecId + "','" + SupplierCode + "','" + BrandCode + "'," + "this" + ",'clater')");               
                tBox.Attributes.Add("onblur","UpdateAmount('" + period + "','" + contractId + "','" + SupplierType + "','" + RefundRecId + "','" + SupplierCode + "','" + BrandCode + "'," + "this" + ",'" + iTax +"')");
                chkPaid.Enabled = chkLater.Checked?false:true;
                chkLater.Enabled = chkPaid.Checked?false:true;
            }            
        }

        protected void gvCashReward_DataBound(object sender, EventArgs e)
        {
            
        }
    }
}
