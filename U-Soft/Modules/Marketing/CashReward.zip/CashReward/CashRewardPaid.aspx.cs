using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using USoft.Globalization.Classes;
using USoft.Common.Shared;
using System.Collections.Generic;
using USoft.Marketing.CashReward;

namespace USoft.Modules.Marketing.CashReward
{
    public partial class CashRewardPaid : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ControlBindingHelper.BindMyDropDownListAsBranch(ddlBranch, false);
                ControlBindingHelper.BindMyDropDownListAsBrand(ddlBrand, false);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Show(1, true);
        }

        private void Show(int MinRow, bool NewSearch)
        {
            List<KeyValuePair<string, object>> ParameterCollection = new List<KeyValuePair<string, object>>();
            ParameterCollection.Add(new KeyValuePair<string, object>("@PERIOD", txtPeriod.Text));
            ParameterCollection.Add(new KeyValuePair<string, object>("@CONDITION", ddlAssetCondition.SelectedValue));
            ParameterCollection.Add(new KeyValuePair<string, object>("@BRAND", ddlBrand.SelectedItem.Text));
            ParameterCollection.Add(new KeyValuePair<string, object>("@BRANCH", ddlBranch.SelectedValue));
            ParameterCollection.Add(new KeyValuePair<string, object>("@TYPE", 0));
            GetCashReward.ShowPaid(ParameterCollection, gvCashRewardPaid, CtrlPager, MinRow, NewSearch);
        }

        public void NextPager(object sender, EventArgs e)
        {
            Label lblCurrPage = (Label)CtrlPager.FindControl("lblCurrent");
            Show(Convert.ToInt16(lblCurrPage.Text), false);
        }

        public void PrevPager(object sender, EventArgs e)
        {
            Label lblCurrPage = (Label)CtrlPager.FindControl("lblCurrent");
            Show(Convert.ToInt16(lblCurrPage.Text), false);
        }

        protected void btnConvert_Click(object sender, EventArgs e)
        {
            List<KeyValuePair<string, object>> ParameterCollection = new List<KeyValuePair<string, object>>();
            ParameterCollection.Add(new KeyValuePair<string, object>("@PERIOD", txtPeriod.Text));
            ParameterCollection.Add(new KeyValuePair<string, object>("@CONDITION", ddlAssetCondition.SelectedValue));
            ParameterCollection.Add(new KeyValuePair<string, object>("@BRAND", ddlBrand.SelectedItem.Text));
            ParameterCollection.Add(new KeyValuePair<string, object>("@BRANCH", ddlBranch.SelectedValue));
            ParameterCollection.Add(new KeyValuePair<string, object>("@TYPE", 0));
            GetCashReward.PaidConvertXls(ParameterCollection);
        }
    }
}
